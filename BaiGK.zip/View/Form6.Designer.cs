﻿namespace _1050080005__TranChau
{
    partial class Form6
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtEmployeeId = new TextBox();
            txtEmployeeEmail = new TextBox();
            txtEmployeePassword = new TextBox();
            rdoAdmin = new RadioButton();
            rdoUser = new RadioButton();
            dataGridView1 = new DataGridView();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            button1 = new Button();
            button2 = new Button();
            groupBox1 = new GroupBox();
            lblStatus = new Label();
            pictureBox1 = new PictureBox();
            button3 = new Button();
            button4 = new Button();
            label5 = new Label();
            txtSearch = new TextBox();
            button5 = new Button();
            label6 = new Label();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // txtEmployeeId
            // 
            txtEmployeeId.Location = new Point(255, 162);
            txtEmployeeId.Name = "txtEmployeeId";
            txtEmployeeId.Size = new Size(229, 27);
            txtEmployeeId.TabIndex = 0;
            // 
            // txtEmployeeEmail
            // 
            txtEmployeeEmail.Location = new Point(255, 195);
            txtEmployeeEmail.Name = "txtEmployeeEmail";
            txtEmployeeEmail.Size = new Size(229, 27);
            txtEmployeeEmail.TabIndex = 2;
            // 
            // txtEmployeePassword
            // 
            txtEmployeePassword.Location = new Point(255, 232);
            txtEmployeePassword.Name = "txtEmployeePassword";
            txtEmployeePassword.Size = new Size(229, 27);
            txtEmployeePassword.TabIndex = 3;
            // 
            // rdoAdmin
            // 
            rdoAdmin.AutoSize = true;
            rdoAdmin.Location = new Point(259, 265);
            rdoAdmin.Name = "rdoAdmin";
            rdoAdmin.Size = new Size(74, 24);
            rdoAdmin.TabIndex = 4;
            rdoAdmin.TabStop = true;
            rdoAdmin.Text = "Admin";
            rdoAdmin.UseVisualStyleBackColor = true;
            // 
            // rdoUser
            // 
            rdoUser.AutoSize = true;
            rdoUser.Location = new Point(339, 265);
            rdoUser.Name = "rdoUser";
            rdoUser.Size = new Size(96, 24);
            rdoUser.TabIndex = 5;
            rdoUser.TabStop = true;
            rdoUser.Text = "Employee";
            rdoUser.UseVisualStyleBackColor = true;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(96, 346);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.Size = new Size(564, 158);
            dataGridView1.TabIndex = 6;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 22.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.ForeColor = SystemColors.ControlText;
            label1.Location = new Point(277, 9);
            label1.Name = "label1";
            label1.Size = new Size(196, 50);
            label1.TabIndex = 7;
            label1.Text = "EMPLOYEE";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(179, 169);
            label2.Name = "label2";
            label2.Size = new Size(24, 20);
            label2.TabIndex = 8;
            label2.Text = "ID";
            label2.Click += label2_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(179, 202);
            label3.Name = "label3";
            label3.Size = new Size(46, 20);
            label3.TabIndex = 9;
            label3.Text = "Email";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(179, 232);
            label4.Name = "label4";
            label4.Size = new Size(70, 20);
            label4.TabIndex = 10;
            label4.Text = "Password";
            // 
            // button1
            // 
            button1.Location = new Point(201, 311);
            button1.Name = "button1";
            button1.Size = new Size(94, 29);
            button1.TabIndex = 11;
            button1.Text = "Submit";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Location = new Point(301, 311);
            button2.Name = "button2";
            button2.Size = new Size(94, 29);
            button2.TabIndex = 12;
            button2.Text = "Delete";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(lblStatus);
            groupBox1.Location = new Point(90, 510);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(616, 115);
            groupBox1.TabIndex = 13;
            groupBox1.TabStop = false;
            groupBox1.Text = "Status";
            // 
            // lblStatus
            // 
            lblStatus.AutoSize = true;
            lblStatus.Location = new Point(6, 23);
            lblStatus.Name = "lblStatus";
            lblStatus.Size = new Size(0, 20);
            lblStatus.TabIndex = 0;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.seoul;
            pictureBox1.Location = new Point(1, -1);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(729, 647);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 14;
            pictureBox1.TabStop = false;
            // 
            // button3
            // 
            button3.Location = new Point(12, 12);
            button3.Name = "button3";
            button3.Size = new Size(94, 29);
            button3.TabIndex = 15;
            button3.Text = "Back";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // button4
            // 
            button4.Location = new Point(401, 311);
            button4.Name = "button4";
            button4.Size = new Size(94, 29);
            button4.TabIndex = 16;
            button4.Text = "Update";
            button4.UseVisualStyleBackColor = true;
            button4.Click += button4_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(179, 265);
            label5.Name = "label5";
            label5.Size = new Size(39, 20);
            label5.TabIndex = 17;
            label5.Text = "Role";
            // 
            // txtSearch
            // 
            txtSearch.Location = new Point(151, 73);
            txtSearch.Name = "txtSearch";
            txtSearch.Size = new Size(387, 27);
            txtSearch.TabIndex = 18;
            // 
            // button5
            // 
            button5.Location = new Point(527, 72);
            button5.Name = "button5";
            button5.Size = new Size(94, 29);
            button5.TabIndex = 19;
            button5.Text = "Search";
            button5.UseVisualStyleBackColor = true;
            button5.Click += button5_Click;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(71, 76);
            label6.Name = "label6";
            label6.Size = new Size(74, 20);
            label6.TabIndex = 20;
            label6.Text = "Tìm kiếm ";
            // 
            // Form6
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(727, 640);
            Controls.Add(label6);
            Controls.Add(button5);
            Controls.Add(txtSearch);
            Controls.Add(label5);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(groupBox1);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(dataGridView1);
            Controls.Add(rdoUser);
            Controls.Add(rdoAdmin);
            Controls.Add(txtEmployeePassword);
            Controls.Add(txtEmployeeEmail);
            Controls.Add(txtEmployeeId);
            Controls.Add(pictureBox1);
            Name = "Form6";
            Text = "Employee";
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtEmployeeId;
        private TextBox txtEmployeeEmail;
        private TextBox txtEmployeePassword;
        private RadioButton rdoAdmin;
        private RadioButton rdoUser;
        private DataGridView dataGridView1;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Button button1;
        private Button button2;
        private GroupBox groupBox1;
        private Label lblStatus;
        private PictureBox pictureBox1;
        private Button button3;
        private Button button4;
        private Label label5;
        private TextBox txtSearch;
        private Button button5;
        private Label label6;
    }
}