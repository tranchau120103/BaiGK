﻿using _1050080005__TranChau.Controller;
using BankDB.Controllers;
using BankDB.Models;

namespace _1050080005__TranChau
{
    public partial class Form3 : Form, IView
    {
        private BranchController _branchController;
        private string selectedBranchId;

        public Form3()
        {
            InitializeComponent();
            _branchController = new BranchController();
            dataGridView1.CellClick += dataGridView1_CellClick;
            this.dataGridView1.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellEndEdit);
            txtBranchId.TextChanged += new EventHandler(TextBox_TextChanged);
            txtBranchName.TextChanged += new EventHandler(TextBox_TextChanged);
            txtBranchHouseNo.TextChanged += new EventHandler(TextBox_TextChanged);
            txtBranchCity.TextChanged += new EventHandler(TextBox_TextChanged);

            CheckFormValidity();  // Kiểm tra tính hợp lệ của form ngay khi khởi 
            // Load dữ liệu khi form load
            LoadBranchData();
        }

        // Load dữ liệu Branch vào DataGridView
        private void LoadBranchData()
        {
            if (_branchController.Load())
            {
                // Gán dữ liệu vào DataGridView nếu thành công
                var branches = _branchController.Items.Cast<Branch>().ToList();
                dataGridView1.DataSource = branches;
            }
            else
            {
                // Nếu không thành công, hiển thị thông báo lỗi
                MessageBox.Show("Không thể tải dữ liệu khách hàng.");
            }
        }

        // Thiết lập dữ liệu từ các ô TextBox dựa trên đối tượng Branch
        public void SetDataToText(object item)
        {
            if (item is Branch branch)
            {
                txtBranchId.Text = branch.Id;
                txtBranchName.Text = branch.Name;
                txtBranchHouseNo.Text = branch.HouseNo;
                txtBranchCity.Text = branch.City;
            }
        }

        // Lấy dữ liệu từ các TextBox và trả về đối tượng Branch
        public object GetDataFromText()
        {
            return new Branch
            {
                Id = txtBranchId.Text,
                Name = txtBranchName.Text,
                HouseNo = txtBranchHouseNo.Text,
                City = txtBranchCity.Text
            };
        }

        // Xử lý sự kiện khi click vào một dòng trong DataGridView
        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow selectedRow = dataGridView1.Rows[e.RowIndex];
                selectedBranchId = selectedRow.Cells["Id"].Value.ToString();
                if (selectedRow.DataBoundItem is Branch customer)
                {
                    SetDataToText(customer); // Hiển thị dữ liệu khách hàng lên các TextBox
                }
            }
        }

        // Xử lý sự kiện chỉnh sửa trực tiếp trong DataGridView
        private void dataGridView1_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                var selectedRow = dataGridView1.Rows[e.RowIndex];
                if (selectedRow.DataBoundItem != null)
                {
                    if (selectedRow.DataBoundItem is Branch branch)
                    {
                        branch.Name = selectedRow.Cells["Name"].Value?.ToString();
                        branch.HouseNo = selectedRow.Cells["HouseNo"].Value?.ToString();
                        branch.City = selectedRow.Cells["City"].Value?.ToString();
                        try
                        {
                            _branchController.Update(branch);
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Error: " + ex.Message);
                        }
                    }
                }
            }
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            // Xử lý sự kiện khi form load
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Branch branch = (Branch)GetDataFromText();
            if (_branchController.Create(branch))
            {
                lblStatus.Text = "Branch added successfully at " + DateTime.Now.ToString("HH:mm:ss");
            }
            else
            {
                lblStatus.Text = "Branch creation failed due to invalid input at " + DateTime.Now.ToString("HH:mm:ss");
            }

            LoadBranchData(); 
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(selectedBranchId))
            {
                _branchController.Delete(selectedBranchId);
                LoadBranchData();

                MessageBox.Show("Branch deleted successfully!");
                selectedBranchId = null;
            }
            else
            {
                MessageBox.Show("Please select a branch to delete.");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form2 f2 = new Form2(UserSession.CurrentUserRole);
            f2.Show();
            this.Hide();
        }

        private void txtBranchName_TextChanged(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            Branch customer = (Branch)GetDataFromText();
            if (_branchController.Update(customer))
            {
                lblStatus.Text = "Branch updated successfully at " + DateTime.Now.ToString("HH:mm:ss");
            }// Cập nhật thông tin khách hàng
            else
            {
                lblStatus.Text = "Branch updated fail because invalid input at " + DateTime.Now.ToString("HH:mm:ss");
            }
            LoadBranchData(); // Tải lại dữ liệu sau khi cập nhật
        }

        private void button5_Click(object sender, EventArgs e)
        {
            string searchId = txtSearch.Text; // Lấy từ khóa tìm kiếm từ TextBox

            if (!string.IsNullOrEmpty(searchId))
            {
                // Gọi phương thức Load(object id) từ controller để tìm kiếm
                if (_branchController.Load(searchId))
                {
                    // Lấy kết quả tìm kiếm từ Items và hiển thị trong DataGridView
                    var customer = _branchController.Items.Cast<Branch>().FirstOrDefault();

                    if (customer != null)
                    {
                        // Hiển thị thông tin khách hàng đã tìm được
                        dataGridView1.DataSource = new List<Branch> { customer };
                    }
                }
                else
                {
                    MessageBox.Show("Customer not found.");
                }
            }
            else
            {
                // Nếu không có từ khóa tìm kiếm, tải lại toàn bộ dữ liệu
                LoadBranchData();
            }
        }
        private void CheckFormValidity()
        {
            // Kiểm tra nếu tất cả các TextBox có dữ liệu
            bool isFormValid = !string.IsNullOrWhiteSpace(txtBranchId.Text)
                            && !string.IsNullOrWhiteSpace(txtBranchName.Text)
                            && !string.IsNullOrWhiteSpace(txtBranchHouseNo.Text)
                            && !string.IsNullOrWhiteSpace(txtBranchCity.Text);

            button1.Enabled = isFormValid; // Thêm mới
            button4.Enabled = isFormValid; // Cập nhật
        }
        private void TextBox_TextChanged(object sender, EventArgs e)
        {
            CheckFormValidity();
        }
        
    }


}
