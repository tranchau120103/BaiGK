﻿
namespace _1050080005__TranChau
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtCustomerName = new TextBox();
            txtCustomerPhone = new TextBox();
            label1 = new Label();
            label3 = new Label();
            Phone = new Label();
            dataGridView1 = new DataGridView();
            txtCustomerHouseNo = new TextBox();
            txtCustomerEmail = new TextBox();
            txtCustomerCity = new TextBox();
            txtCustomerPin = new TextBox();
            label5 = new Label();
            label7 = new Label();
            label8 = new Label();
            label9 = new Label();
            button1 = new Button();
            button2 = new Button();
            pictureBox1 = new PictureBox();
            groupBox1 = new GroupBox();
            lblStatus = new Label();
            button3 = new Button();
            txtSearch = new TextBox();
            button4 = new Button();
            label4 = new Label();
            button5 = new Button();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // txtCustomerName
            // 
            txtCustomerName.Location = new Point(176, 119);
            txtCustomerName.Name = "txtCustomerName";
            txtCustomerName.Size = new Size(163, 27);
            txtCustomerName.TabIndex = 1;
            // 
            // txtCustomerPhone
            // 
            txtCustomerPhone.Location = new Point(176, 152);
            txtCustomerPhone.Name = "txtCustomerPhone";
            txtCustomerPhone.Size = new Size(163, 27);
            txtCustomerPhone.TabIndex = 2;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(66, 185);
            label1.Name = "label1";
            label1.Size = new Size(46, 20);
            label1.TabIndex = 3;
            label1.Text = "Email";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(66, 122);
            label3.Name = "label3";
            label3.Size = new Size(49, 20);
            label3.TabIndex = 5;
            label3.Text = "Name";
            label3.Click += label3_Click;
            // 
            // Phone
            // 
            Phone.AutoSize = true;
            Phone.Location = new Point(66, 152);
            Phone.Name = "Phone";
            Phone.Size = new Size(104, 20);
            Phone.TabIndex = 6;
            Phone.Text = "PhoneNumber";
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.GridColor = SystemColors.ScrollBar;
            dataGridView1.Location = new Point(103, 304);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.Size = new Size(565, 190);
            dataGridView1.TabIndex = 7;
            dataGridView1.CellContentClick += dataGridView1_CellContentClick;
            // 
            // txtCustomerHouseNo
            // 
            txtCustomerHouseNo.Location = new Point(462, 119);
            txtCustomerHouseNo.Name = "txtCustomerHouseNo";
            txtCustomerHouseNo.Size = new Size(163, 27);
            txtCustomerHouseNo.TabIndex = 10;
            txtCustomerHouseNo.TextChanged += txtCustomerHouseNo_TextChanged;
            // 
            // txtCustomerEmail
            // 
            txtCustomerEmail.Location = new Point(176, 185);
            txtCustomerEmail.Name = "txtCustomerEmail";
            txtCustomerEmail.Size = new Size(163, 27);
            txtCustomerEmail.TabIndex = 11;
            txtCustomerEmail.TextChanged += txtCustomerEmail_TextChanged;
            // 
            // txtCustomerCity
            // 
            txtCustomerCity.Location = new Point(462, 152);
            txtCustomerCity.Name = "txtCustomerCity";
            txtCustomerCity.Size = new Size(163, 27);
            txtCustomerCity.TabIndex = 12;
            txtCustomerCity.TextChanged += txtCustomerCity_TextChanged;
            // 
            // txtCustomerPin
            // 
            txtCustomerPin.Location = new Point(462, 185);
            txtCustomerPin.Name = "txtCustomerPin";
            txtCustomerPin.Size = new Size(163, 27);
            txtCustomerPin.TabIndex = 13;
            txtCustomerPin.TextChanged += txtCustomerPin_TextChanged;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(382, 122);
            label5.Name = "label5";
            label5.Size = new Size(71, 20);
            label5.TabIndex = 15;
            label5.Text = "HouseNo";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(384, 185);
            label7.Name = "label7";
            label7.Size = new Size(32, 20);
            label7.TabIndex = 17;
            label7.Text = "PIN";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(382, 152);
            label8.Name = "label8";
            label8.Size = new Size(34, 20);
            label8.TabIndex = 18;
            label8.Text = "City";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.BackColor = Color.Transparent;
            label9.Font = new Font("Segoe UI", 22.2F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label9.ForeColor = SystemColors.ControlText;
            label9.Location = new Point(264, 9);
            label9.Name = "label9";
            label9.Size = new Size(209, 50);
            label9.TabIndex = 19;
            label9.Text = "CUSTOMER";
            label9.Click += label9_Click;
            // 
            // button1
            // 
            button1.Location = new Point(103, 269);
            button1.Name = "button1";
            button1.Size = new Size(94, 29);
            button1.TabIndex = 20;
            button1.Text = "Submit";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Location = new Point(203, 269);
            button2.Name = "button2";
            button2.Size = new Size(94, 29);
            button2.TabIndex = 21;
            button2.Text = "Delete";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.BackColor = Color.Transparent;
            pictureBox1.Image = Properties.Resources.seoul;
            pictureBox1.Location = new Point(-21, -1);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(790, 610);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 22;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(lblStatus);
            groupBox1.Location = new Point(103, 500);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(576, 109);
            groupBox1.TabIndex = 23;
            groupBox1.TabStop = false;
            groupBox1.Text = "Status";
            // 
            // lblStatus
            // 
            lblStatus.AutoSize = true;
            lblStatus.Location = new Point(8, 23);
            lblStatus.Name = "lblStatus";
            lblStatus.Size = new Size(0, 20);
            lblStatus.TabIndex = 0;
            // 
            // button3
            // 
            button3.Location = new Point(303, 269);
            button3.Name = "button3";
            button3.Size = new Size(94, 29);
            button3.TabIndex = 24;
            button3.Text = "Update";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // txtSearch
            // 
            txtSearch.Location = new Point(117, 62);
            txtSearch.Name = "txtSearch";
            txtSearch.Size = new Size(395, 27);
            txtSearch.TabIndex = 25;
            // 
            // button4
            // 
            button4.Location = new Point(496, 62);
            button4.Name = "button4";
            button4.Size = new Size(94, 29);
            button4.TabIndex = 26;
            button4.Text = "Search ";
            button4.UseVisualStyleBackColor = true;
            button4.Click += button4_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(37, 66);
            label4.Name = "label4";
            label4.Size = new Size(74, 20);
            label4.TabIndex = 27;
            label4.Text = "Tìm kiếm ";
            // 
            // button5
            // 
            button5.Location = new Point(7, 9);
            button5.Name = "button5";
            button5.Size = new Size(94, 29);
            button5.TabIndex = 28;
            button5.Text = "Back";
            button5.UseVisualStyleBackColor = true;
            button5.Click += button5_Click;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(762, 626);
            Controls.Add(button5);
            Controls.Add(label4);
            Controls.Add(button4);
            Controls.Add(txtSearch);
            Controls.Add(button3);
            Controls.Add(groupBox1);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(label9);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(label5);
            Controls.Add(txtCustomerPin);
            Controls.Add(txtCustomerCity);
            Controls.Add(txtCustomerEmail);
            Controls.Add(txtCustomerHouseNo);
            Controls.Add(dataGridView1);
            Controls.Add(Phone);
            Controls.Add(label3);
            Controls.Add(label1);
            Controls.Add(txtCustomerPhone);
            Controls.Add(txtCustomerName);
            Controls.Add(pictureBox1);
            Name = "Form1";
            Text = "Customer";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private TextBox txtCustomerName;
        private TextBox txtCustomerPhone;
        private Label label1;
        private Label label3;
        private Label Phone;
        private DataGridView dataGridView1;
        private RadioButton radioButton1;
        private RadioButton radioButton2;
        private TextBox txtCustomerHouseNo;
        private TextBox txtCustomerEmail;
        private TextBox txtCustomerCity;
        private TextBox txtCustomerPin;
        private Label label5;
        private Label label7;
        private Label label8;
        private Label label9;
        private Button button1;
        private Button button2;
        private PictureBox pictureBox1;
        private GroupBox groupBox1;
        private Label lblStatus;
        private Button button3;
        private TextBox txtSearch;
        private Button button4;
        private Label label4;
        private Button button5;
    }
}