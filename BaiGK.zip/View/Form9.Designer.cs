﻿namespace _1050080005__TranChau
{
    partial class Form9
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            groupBox1 = new GroupBox();
            lblStatus = new Label();
            button1 = new Button();
            txtAccountId = new TextBox();
            txtAmount = new TextBox();
            button3 = new Button();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 19.8000011F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.ForeColor = SystemColors.ControlText;
            label3.Location = new Point(155, 47);
            label3.Name = "label3";
            label3.Size = new Size(353, 46);
            label3.TabIndex = 14;
            label3.Text = "WITHDRAW AMOUNT";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(155, 189);
            label2.Name = "label2";
            label2.Size = new Size(62, 20);
            label2.TabIndex = 13;
            label2.Text = "Amount";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(155, 142);
            label1.Name = "label1";
            label1.Size = new Size(86, 20);
            label1.TabIndex = 8;
            label1.Text = "Account ID ";
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(lblStatus);
            groupBox1.Location = new Point(114, 298);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(426, 125);
            groupBox1.TabIndex = 12;
            groupBox1.TabStop = false;
            groupBox1.Text = "Status";
            // 
            // lblStatus
            // 
            lblStatus.AutoSize = true;
            lblStatus.Location = new Point(19, 28);
            lblStatus.Name = "lblStatus";
            lblStatus.Size = new Size(50, 20);
            lblStatus.TabIndex = 0;
            lblStatus.Text = "label1";
            // 
            // button1
            // 
            button1.Location = new Point(389, 239);
            button1.Name = "button1";
            button1.Size = new Size(83, 29);
            button1.TabIndex = 10;
            button1.Text = "Withdraw";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // txtAccountId
            // 
            txtAccountId.Location = new Point(275, 142);
            txtAccountId.Name = "txtAccountId";
            txtAccountId.Size = new Size(197, 27);
            txtAccountId.TabIndex = 9;
            // 
            // txtAmount
            // 
            txtAmount.Location = new Point(275, 189);
            txtAmount.Name = "txtAmount";
            txtAmount.Size = new Size(197, 27);
            txtAmount.TabIndex = 7;
            // 
            // button3
            // 
            button3.Location = new Point(12, 12);
            button3.Name = "button3";
            button3.Size = new Size(94, 29);
            button3.TabIndex = 15;
            button3.Text = "Back";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // Form9
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.seoul;
            ClientSize = new Size(613, 450);
            Controls.Add(button3);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(groupBox1);
            Controls.Add(button1);
            Controls.Add(txtAccountId);
            Controls.Add(txtAmount);
            Name = "Form9";
            Text = "WithdrawAmount";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label3;
        private Label label2;
        private Label label1;
        private GroupBox groupBox1;
        private Label lblStatus;
        private Button button1;
        private TextBox txtAccountId;
        private TextBox txtAmount;
        private Button button3;
    }
}