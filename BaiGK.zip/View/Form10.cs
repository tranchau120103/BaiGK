﻿using _1050080005__TranChau.Controller;
using BankDB.Controllers;

namespace _1050080005__TranChau
{
    public partial class Form10 : Form
    {
        private AccountController _balanceController;

        public Form10()
        {
            InitializeComponent();
            _balanceController = new AccountController();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string accountId = txtAccountId.Text; // Lấy ID tài khoản từ textbox

            // Gọi phương thức để lấy số dư tài khoản
            double? balance = _balanceController.GetAccountBalance(accountId);

            if (balance.HasValue)
            {
                label2.Text = $"Số dư tài khoản: {balance.Value} VND"; // Hiển thị số dư
                lblStatus.Text = "Lấy số dư thành công.";
            }
            else
            {
                label2.Text = "Tài khoản không tồn tại.";
                lblStatus.Text = "Không thể lấy số dư.";
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form8 f8 = new Form8();
            f8.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form9 f8 = new Form9();
            f8.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Form2 form2 = new Form2(UserSession.CurrentUserRole);
            form2.Show();
            this.Hide();
        }
    }
}
