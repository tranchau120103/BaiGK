﻿using BankDB.Controllers;
using BankDB.Models;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _1050080005__TranChau
{
    public partial class Form14 : Form
    {
        CustomerController _customerController;
        public Form14()
        {
            InitializeComponent();
            _customerController = new CustomerController();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string phoneNumber = txtPhoneNumber.Text; // Lấy số điện thoại từ TextBox
            string newPin = txtPin.Text; // Lấy mã PIN mới từ TextBox

            // Kiểm tra xem số điện thoại và mã PIN mới đã được nhập đầy đủ hay chưa
            if (string.IsNullOrEmpty(phoneNumber) || string.IsNullOrEmpty(newPin))
            {
                MessageBox.Show("Vui lòng nhập đầy đủ số điện thoại và mã PIN mới.");
                return;
            }

            // Gọi phương thức thay đổi mã PIN
            if (ChangePin(phoneNumber, newPin))
            {
                MessageBox.Show("Thay đổi mã PIN thành công.");
            }
            else
            {
                MessageBox.Show("Không tìm thấy số điện thoại này.");
            }
        }
        private bool ChangePin(string phoneNumber, string newPin)
        {
            // Nạp dữ liệu khách hàng từ cơ sở dữ liệu
            _customerController.Load(); // Đảm bảo đã load dữ liệu khách hàng

            // Tìm khách hàng dựa trên số điện thoại
            var customer = _customerController.Items
                .Cast<Customer>()
                .FirstOrDefault(c => c.Phone.Equals(phoneNumber, StringComparison.OrdinalIgnoreCase));

            if (customer != null)
            {
                // Cập nhật mã PIN mới
                customer.Pin = newPin;

                // Gọi phương thức Update để lưu thay đổi vào cơ sở dữ liệu
                return _customerController.Update(customer);
            }

            // Không tìm thấy khách hàng với số điện thoại này
            return false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form13 f13 = new Form13();
            f13.Show();
            this.Hide();
        }

        private void Form14_Load(object sender, EventArgs e)
        {

        }
    }
}
