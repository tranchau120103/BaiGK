﻿namespace _1050080005__TranChau
{
    partial class Form11
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtFromAccountId = new TextBox();
            txtBranchId = new TextBox();
            txtPin = new TextBox();
            txtToAccountId = new TextBox();
            txtEmployeeId = new TextBox();
            button1 = new Button();
            txtAmount = new TextBox();
            groupBox1 = new GroupBox();
            lblStatus = new Label();
            label1 = new Label();
            labe = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label2 = new Label();
            pictureBox1 = new PictureBox();
            label7 = new Label();
            button3 = new Button();
            groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // txtFromAccountId
            // 
            txtFromAccountId.Location = new Point(179, 139);
            txtFromAccountId.Name = "txtFromAccountId";
            txtFromAccountId.Size = new Size(209, 27);
            txtFromAccountId.TabIndex = 0;
            // 
            // txtBranchId
            // 
            txtBranchId.Location = new Point(499, 139);
            txtBranchId.Name = "txtBranchId";
            txtBranchId.Size = new Size(209, 27);
            txtBranchId.TabIndex = 1;
            // 
            // txtPin
            // 
            txtPin.Location = new Point(179, 208);
            txtPin.Name = "txtPin";
            txtPin.Size = new Size(209, 27);
            txtPin.TabIndex = 2;
            // 
            // txtToAccountId
            // 
            txtToAccountId.Location = new Point(179, 175);
            txtToAccountId.Name = "txtToAccountId";
            txtToAccountId.Size = new Size(209, 27);
            txtToAccountId.TabIndex = 3;
            // 
            // txtEmployeeId
            // 
            txtEmployeeId.Location = new Point(499, 172);
            txtEmployeeId.Name = "txtEmployeeId";
            txtEmployeeId.Size = new Size(209, 27);
            txtEmployeeId.TabIndex = 4;
            // 
            // button1
            // 
            button1.Location = new Point(614, 306);
            button1.Name = "button1";
            button1.Size = new Size(94, 29);
            button1.TabIndex = 5;
            button1.Text = "Transaction";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // txtAmount
            // 
            txtAmount.Location = new Point(499, 205);
            txtAmount.Name = "txtAmount";
            txtAmount.Size = new Size(209, 27);
            txtAmount.TabIndex = 8;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(lblStatus);
            groupBox1.Location = new Point(107, 361);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(620, 125);
            groupBox1.TabIndex = 9;
            groupBox1.TabStop = false;
            groupBox1.Text = "groupBox1";
            // 
            // lblStatus
            // 
            lblStatus.AutoSize = true;
            lblStatus.Location = new Point(20, 23);
            lblStatus.Name = "lblStatus";
            lblStatus.Size = new Size(50, 20);
            lblStatus.TabIndex = 0;
            lblStatus.Text = "label1";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(46, 175);
            label1.Name = "label1";
            label1.Size = new Size(127, 20);
            label1.TabIndex = 10;
            label1.Text = "Người thụ hưởng ";
            // 
            // labe
            // 
            labe.AutoSize = true;
            labe.Location = new Point(46, 145);
            labe.Name = "labe";
            labe.Size = new Size(105, 20);
            labe.TabIndex = 11;
            labe.Text = "Người chuyển ";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(7, 205);
            label3.Name = "label3";
            label3.Size = new Size(0, 20);
            label3.TabIndex = 12;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(405, 142);
            label4.Name = "label4";
            label4.Size = new Size(69, 20);
            label4.TabIndex = 13;
            label4.Text = "IDBranch";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(405, 175);
            label5.Name = "label5";
            label5.Size = new Size(88, 20);
            label5.TabIndex = 14;
            label5.Text = "EmployeeId";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(405, 211);
            label6.Name = "label6";
            label6.Size = new Size(62, 20);
            label6.TabIndex = 15;
            label6.Text = "Amount";
            label6.Click += label6_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(46, 215);
            label2.Name = "label2";
            label2.Size = new Size(36, 20);
            label2.TabIndex = 16;
            label2.Text = "PIN ";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.seoul;
            pictureBox1.Location = new Point(-4, -6);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(812, 544);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 17;
            pictureBox1.TabStop = false;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.BackColor = Color.Transparent;
            label7.Font = new Font("Segoe UI", 19.8000011F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label7.ForeColor = SystemColors.ControlText;
            label7.Location = new Point(284, 44);
            label7.Name = "label7";
            label7.Size = new Size(252, 46);
            label7.TabIndex = 18;
            label7.Text = "TRANSACTION ";
            // 
            // button3
            // 
            button3.Location = new Point(7, 12);
            button3.Name = "button3";
            button3.Size = new Size(94, 29);
            button3.TabIndex = 19;
            button3.Text = "Back ";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // Form11
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 531);
            Controls.Add(button3);
            Controls.Add(label7);
            Controls.Add(label2);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(labe);
            Controls.Add(label1);
            Controls.Add(groupBox1);
            Controls.Add(txtAmount);
            Controls.Add(button1);
            Controls.Add(txtEmployeeId);
            Controls.Add(txtToAccountId);
            Controls.Add(txtPin);
            Controls.Add(txtBranchId);
            Controls.Add(txtFromAccountId);
            Controls.Add(pictureBox1);
            Name = "Form11";
            Text = "Transaction";
            Load += Form11_Load;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtFromAccountId;
        private TextBox txtBranchId;
        private TextBox txtPin;
        private TextBox txtToAccountId;
        private TextBox txtEmployeeId;
        private Button button1;
        private TextBox txtAmount;
        private GroupBox groupBox1;
        private Label lblStatus;
        private Label label1;
        private Label labe;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label2;
        private PictureBox pictureBox1;
        private Label label7;
        private Button button3;
    }
}