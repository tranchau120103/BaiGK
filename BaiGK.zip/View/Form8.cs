﻿using _1050080005__TranChau.Controller;
using BankDB.Controllers;

namespace _1050080005__TranChau
{
    public partial class Form8 : Form
    {
        private DepositController _depositController;

        public Form8()
        {
            InitializeComponent();
            _depositController = new DepositController();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string accountId = txtAccountId.Text; // Lấy ID tài khoản từ textbox
            double amount;

            // Kiểm tra xem số tiền nhập vào có phải là một số hợp lệ không
            if (double.TryParse(txtAmount.Text, out amount) && amount > 0)
            {
                bool success = _depositController.DepositAmount(accountId, amount);

                if (success)
                {
                    lblStatus.Text = "Nạp tiền thành công!";
                    MessageBox.Show("Nạp tiền thành công!");
                }
                else
                {
                    lblStatus.Text = "Tài khoản không tồn tại hoặc số tiền không hợp lệ.";
                    MessageBox.Show("Tài khoản không tồn tại hoặc số tiền không hợp lệ.");
                }
            }
            else
            {
                MessageBox.Show("Vui lòng nhập một số tiền hợp lệ.");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form2 f2 = new Form2(UserSession.CurrentUserRole);
            f2.Show();
            this.Hide();
        }
    }
}
