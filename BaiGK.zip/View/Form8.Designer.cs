﻿namespace _1050080005__TranChau
{
    partial class Form8
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtAmount = new TextBox();
            txtAccountId = new TextBox();
            button1 = new Button();
            button2 = new Button();
            groupBox1 = new GroupBox();
            lblStatus = new Label();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            button3 = new Button();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // txtAmount
            // 
            txtAmount.Location = new Point(199, 258);
            txtAmount.Name = "txtAmount";
            txtAmount.Size = new Size(197, 27);
            txtAmount.TabIndex = 0;
            // 
            // txtAccountId
            // 
            txtAccountId.Location = new Point(199, 211);
            txtAccountId.Name = "txtAccountId";
            txtAccountId.Size = new Size(197, 27);
            txtAccountId.TabIndex = 1;
            // 
            // button1
            // 
            button1.Location = new Point(200, 319);
            button1.Name = "button1";
            button1.Size = new Size(73, 29);
            button1.TabIndex = 2;
            button1.Text = "Deposit";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Location = new Point(302, 319);
            button2.Name = "button2";
            button2.Size = new Size(82, 29);
            button2.TabIndex = 3;
            button2.Text = "button2";
            button2.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(lblStatus);
            groupBox1.Location = new Point(111, 376);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(426, 125);
            groupBox1.TabIndex = 4;
            groupBox1.TabStop = false;
            groupBox1.Text = "Status";
            // 
            // lblStatus
            // 
            lblStatus.AutoSize = true;
            lblStatus.Location = new Point(19, 28);
            lblStatus.Name = "lblStatus";
            lblStatus.Size = new Size(50, 20);
            lblStatus.TabIndex = 0;
            lblStatus.Text = "label1";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(111, 214);
            label1.Name = "label1";
            label1.Size = new Size(82, 20);
            label1.TabIndex = 1;
            label1.Text = "AccountID ";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(111, 265);
            label2.Name = "label2";
            label2.Size = new Size(62, 20);
            label2.TabIndex = 5;
            label2.Text = "Amount";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 19.8000011F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.ForeColor = SystemColors.ControlText;
            label3.Location = new Point(148, 101);
            label3.Name = "label3";
            label3.Size = new Size(305, 46);
            label3.TabIndex = 6;
            label3.Text = "DEPOSIT AMOUNT";
            // 
            // button3
            // 
            button3.Location = new Point(12, 12);
            button3.Name = "button3";
            button3.Size = new Size(94, 29);
            button3.TabIndex = 7;
            button3.Text = "Back";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // Form8
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.seoul;
            ClientSize = new Size(604, 549);
            Controls.Add(button3);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(groupBox1);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(txtAccountId);
            Controls.Add(txtAmount);
            Name = "Form8";
            Text = "DepositAmount";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtAmount;
        private TextBox txtAccountId;
        private Button button1;
        private Button button2;
        private GroupBox groupBox1;
        private Label lblStatus;
        private Label label1;
        private Label label2;
        private Label label3;
        private Button button3;
    }
}