﻿using _1050080005__TranChau.Controller;
using BankDB.Controllers;
using BankDB.Models;

namespace _1050080005__TranChau
{
    public partial class Form6 : Form, IView
    {
        private EmployeeController _employeeController;
        private string selectedEmployeeId;

        public Form6()
        {
            InitializeComponent();
            _employeeController = new EmployeeController();
            dataGridView1.CellClick += dataGridView1_CellClick;
            this.dataGridView1.CellEndEdit += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellEndEdit);
            txtEmployeeId.TextChanged += new EventHandler(TextBox_TextChanged);
            txtEmployeeEmail.TextChanged += new EventHandler(TextBox_TextChanged);
            txtEmployeePassword.TextChanged += new EventHandler(TextBox_TextChanged);

            CheckFormValidity();

            LoadEmployeeData();
        }

        private void LoadEmployeeData()
        {
            // Tắt tự động tạo cột
            dataGridView1.AutoGenerateColumns = false;

            // Tải dữ liệu từ cơ sở dữ liệu
            if (_employeeController.Load())
            {
                // Gán dữ liệu vào DataGridView nếu thành công
                var employees = _employeeController.Items.Cast<Employee>().ToList();
                dataGridView1.DataSource = employees;
            }
            else
            {
                // Nếu không thành công, hiển thị thông báo lỗi
                MessageBox.Show("Không thể tải dữ liệu khách hàng.");
            }
            // Xóa cột hiện có để đảm bảo không trùng lặp
            dataGridView1.Columns.Clear();

            // Tạo cột ID
            dataGridView1.Columns.Add(new DataGridViewTextBoxColumn
            {
                HeaderText = "ID",
                DataPropertyName = "Id",
                Name = "Id"
            });

            // Tạo cột Email
            dataGridView1.Columns.Add(new DataGridViewTextBoxColumn
            {
                HeaderText = "Email",
                DataPropertyName = "Email",
                Name = "Email"
            });
            dataGridView1.Columns.Add(new DataGridViewTextBoxColumn
            {
                HeaderText = "Password",
                DataPropertyName = "Password",
                Name = "Password"
            });
            // Tạo ComboBox cho cột Role
            DataGridViewComboBoxColumn roleColumn = new DataGridViewComboBoxColumn();
            roleColumn.HeaderText = "Role";
            roleColumn.DataPropertyName = "Role"; // Thuộc tính Role trong đối tượng Employee
            roleColumn.Name = "Role";
            roleColumn.Items.AddRange("Admin", "NV"); // Các giá trị khớp với dữ liệu cơ sở

            // Thêm cột ComboBox vào DataGridView
            dataGridView1.Columns.Add(roleColumn);
        }


        public void SetDataToText(object item)
        {
            if (item is Employee employee)
            {
                txtEmployeeId.Text = employee.Id;
                txtEmployeePassword.Text = employee.Password;
                txtEmployeeEmail.Text = employee.Email;

                // Kiểm tra vai trò của nhân viên và đặt giá trị cho các RadioButton
                if (employee.Role == "Admin")
                {
                    rdoAdmin.Checked = true;
                }
                else if (employee.Role == "NV")
                {
                    rdoUser.Checked = true;
                }
            }
        }


        // Phương thức này lấy dữ liệu từ các TextBox và trả về một đối tượng `Employee`
        public object GetDataFromText()
        {
            string role = "";

            // Kiểm tra RadioButton nào đang được chọn và đặt giá trị tương ứng cho Role
            if (rdoAdmin.Checked)
            {
                role = "Admin";
            }
            else if (rdoUser.Checked)
            {
                role = "NV";
            }

            return new Employee
            {
                Id = txtEmployeeId.Text,
                Password = txtEmployeePassword.Text,
                Email = txtEmployeeEmail.Text,
                Role = role // Gán vai trò từ RadioButton
            };
        }


        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0) // Kiểm tra nếu dòng được chọn là hợp lệ
            {
                DataGridViewRow selectedRow = dataGridView1.Rows[e.RowIndex];
                int employeeId = Convert.ToInt32(selectedRow.Cells["Id"].Value);
                selectedEmployeeId = employeeId.ToString();
                if (selectedRow.DataBoundItem is Employee customer)
                {
                    SetDataToText(customer); // Hiển thị dữ liệu khách hàng lên các TextBox
                }
            }
        }

        private void dataGridView1_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                var selectedRow = dataGridView1.Rows[e.RowIndex];

                if (selectedRow.DataBoundItem != null)
                {
                    if (selectedRow.DataBoundItem is Employee employee)
                    {
                        employee.Email = selectedRow.Cells["Email"].Value?.ToString();
                        employee.Password = selectedRow.Cells["Password"].Value?.ToString();
                        var selectedRole = selectedRow.Cells["Role"].Value?.ToString();
                        if (!string.IsNullOrEmpty(selectedRole))
                        {
                            employee.Role = selectedRole; // Cập nhật vai trò
                        }
                        try
                        {
                            _employeeController.Update(employee);
                        }
                        catch (Exception ex)
                        {
                            // Handle exception
                        }
                    }
                }
            }
        }


        private void Form6_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Employee branch = (Employee)GetDataFromText();
            if (_employeeController.Create(branch))
            {
                lblStatus.Text = "Employee added successfully at " + DateTime.Now.ToString("HH:mm:ss");
            }
            else
            {
                lblStatus.Text = "Employee creation failed due to invalid input at " + DateTime.Now.ToString("HH:mm:ss");
            }

            LoadEmployeeData();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(selectedEmployeeId))
            {
                _employeeController.Delete(selectedEmployeeId);
                LoadEmployeeData();
                MessageBox.Show("Employee deleted successfully!");
                selectedEmployeeId = null;
            }
            else
            {
                MessageBox.Show("Please select an employee to delete.");
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form2 f2 = new Form2(UserSession.CurrentUserRole);
            f2.Show();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Employee customer = (Employee)GetDataFromText();
            if (_employeeController.Update(customer))
            {
                lblStatus.Text = "Employee updated successfully at " + DateTime.Now.ToString("HH:mm:ss");
            }
            else
            {
                lblStatus.Text = "Employee updated fail because invalid input at " + DateTime.Now.ToString("HH:mm:ss");
            }
            LoadEmployeeData();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            string searchId = txtSearch.Text; // Lấy từ khóa tìm kiếm từ TextBox

            if (!string.IsNullOrEmpty(searchId))
            {
                // Gọi phương thức Load(object id) từ controller để tìm kiếm
                if (_employeeController.Load(searchId))
                {
                    // Lấy kết quả tìm kiếm từ Items và hiển thị trong DataGridView
                    var customer = _employeeController.Items.Cast<Employee>().FirstOrDefault();
                    if (customer != null)
                    {
                        // Hiển thị thông tin khách hàng đã tìm được trong DataGridView
                        dataGridView1.DataSource = new List<Employee> { customer };
                    }
                    else
                    {
                        MessageBox.Show("Không tìm thấy khách hàng.");
                    }
                }
                else
                {
                    MessageBox.Show("Không tìm thấy khách hàng.");
                }
            }
            else
            {
                // Nếu không có từ khóa tìm kiếm, tải lại toàn bộ dữ liệu
                LoadEmployeeData();
            }
        }
        private void CheckFormValidity()
        {
            bool isFormValid = !string.IsNullOrWhiteSpace(txtEmployeeId.Text)
                            && !string.IsNullOrWhiteSpace(txtEmployeeEmail.Text)
                            && !string.IsNullOrWhiteSpace(txtEmployeePassword.Text);

            button1.Enabled = isFormValid; // Thêm mới
            button4.Enabled = isFormValid; // Cập nhật
        }

        private void TextBox_TextChanged(object sender, EventArgs e)
        {
            CheckFormValidity();
        }
    }
}
