﻿using BankDB.Controllers;
using BankDB.Models;
using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using _1050080005__TranChau.Controller;
namespace _1050080005__TranChau
{

    public partial class Form13 : Form
    {
        CustomerController customerController;
        public Form13()
        {
            InitializeComponent();
            customerController = new CustomerController();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string phoneNumber = txtPhoneNumber.Text; // Lấy số điện thoại từ TextBox
            string enteredPin = txtPin.Text; // Lấy mã PIN từ TextBox

            // Kiểm tra xem số điện thoại và mã PIN đã được nhập đầy đủ hay chưa
            if (string.IsNullOrEmpty(phoneNumber) || string.IsNullOrEmpty(enteredPin))
            {
                MessageBox.Show("Vui lòng nhập đầy đủ số điện thoại và mã PIN.");
                return;
            }

            // Gọi phương thức kiểm tra đăng nhập với số điện thoại và mã PIN
            if (IsValidPhoneAndPin(phoneNumber, enteredPin, out string customerId))
            {
                UserSession.SetUserRole("KH");

                // Hiển thị ID của khách hàng trong MessageBox
                MessageBox.Show($"Đăng nhập thành công! ID của bạn là: {customerId}", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);

                UserSession.SetCustomerId(customerId);
                // Đăng nhập thành công, mở Form tiếp theo
                Form2 mainForm = new Form2("KH"); // Chuyển quyền user nếu cần thiết
                mainForm.Show();
                this.Hide();
            }
            else
            {
                // Nếu đăng nhập không thành công
                MessageBox.Show("Số điện thoại hoặc mã PIN không hợp lệ.");
            }
        }

        private bool IsValidPhoneAndPin(string phoneNumber, string enteredPin, out string customerId)
        {
            customerController.Load(); // Đảm bảo đã load dữ liệu khách hàng

            // Kiểm tra khách hàng dựa trên số điện thoại và mã PIN
            var customer = customerController.Items
                .Cast<Customer>()
                .FirstOrDefault(c =>
                    c.Phone.Equals(phoneNumber, StringComparison.OrdinalIgnoreCase) &&
                    c.Pin.Equals(enteredPin, StringComparison.OrdinalIgnoreCase));

            // Nếu tìm thấy khách hàng, lưu lại role và trả về true
            if (customer != null)
            {
                customerId = customer.Id; // Lưu ID của khách hàng
                return true;
            }

            // Không tìm thấy khách hàng
            customerId = null; // Gán giá trị null nếu không tìm thấy
            return false;
        }


        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form14 f14 = new Form14();
            f14.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form15 f15 = new Form15();
            f15.Show();
            this.Hide();
        }
    }
}
