﻿using _1050080005__TranChau.Controller;
using BankDB.Controllers;
using BankDB.Models;
using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace _1050080005__TranChau
{
    public partial class Form7 : Form, IView
    {
        private AccountController _accountController;
        private string selectedAccountId;

        public Form7()
        {
            InitializeComponent();
            _accountController = new AccountController();
            dataGridView1.CellClick += dataGridView1_CellClick;
            this.dataGridView1.CellEndEdit += new DataGridViewCellEventHandler(this.dataGridView1_CellEndEdit);
            txtAccountId.TextChanged += new EventHandler(TextBox_TextChanged);
            txtCustomerId.TextChanged += new EventHandler(TextBox_TextChanged);
            txtDateOpened.TextChanged += new EventHandler(TextBox_TextChanged);
            txtBalance.TextChanged += new EventHandler(TextBox_TextChanged);
            CheckFormValidity();
            // Gọi hàm để tải dữ liệu Account vào DataGridView khi form load
            LoadAccountData();
        }
        private void CheckFormValidity()
        {
            bool isFormValid = !string.IsNullOrWhiteSpace(txtAccountId.Text)
                            && !string.IsNullOrWhiteSpace(txtCustomerId.Text)
                            && !string.IsNullOrWhiteSpace(txtDateOpened.Text)
                            && !string.IsNullOrWhiteSpace(txtBalance.Text);

            button1.Enabled = isFormValid; // Thêm
            button4.Enabled = isFormValid; // Cập nhật
        }

        // Gọi khi TextBox có thay đổi
        private void TextBox_TextChanged(object sender, EventArgs e)
        {
            CheckFormValidity();
        }
        // Tải danh sách Account lên DataGridView
        private void LoadAccountData()
        {
            if (_accountController.Load())
            {
                // Gán dữ liệu vào DataGridView nếu thành công
                var accounts = _accountController.Items.Cast<Account>().ToList();
                dataGridView1.DataSource = accounts;
            }
            else
            {
                // Nếu không thành công, hiển thị thông báo lỗi
                MessageBox.Show("Không thể tải dữ liệu khách hàng.");
            }
            dataGridView1.Columns["Customer"].Visible = false;
            dataGridView1.Columns["TransactionFromAccounts"].Visible = false;
            dataGridView1.Columns["TransactionToAccounts"].Visible = false;
        }

        // Hiển thị thông tin tài khoản vào các TextBox
        public void SetDataToText(object item)
        {
            if (item is Account account)
            {
                txtAccountId.Text = account.Id;
                txtCustomerId.Text = account.Customerid;
                txtDateOpened.Text = account.DateOpened?.ToString("yyyy-MM-dd");
                txtBalance.Text = account.Balance?.ToString();
            }
        }

        // Lấy dữ liệu từ các TextBox và trả về một đối tượng `Account`
        public object GetDataFromText()
        {
            return new Account
            {
                Id = txtAccountId.Text,
                Customerid = txtCustomerId.Text,
                DateOpened = DateOnly.Parse(txtDateOpened.Text),
                Balance = double.Parse(txtBalance.Text)
            };
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0) // Kiểm tra nếu dòng được chọn là hợp lệ
            {
                // Lấy giá trị của cột "Id" từ dòng được chọn
                DataGridViewRow selectedRow = dataGridView1.Rows[e.RowIndex];
                string accountId = selectedRow.Cells["Id"].Value.ToString();

                selectedAccountId = accountId;
                if (selectedRow.DataBoundItem is Account customer)
                {
                    SetDataToText(customer); // Hiển thị dữ liệu khách hàng lên các TextBox
                }
            }
        }

        private void dataGridView1_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                var selectedRow = dataGridView1.Rows[e.RowIndex];

                if (selectedRow.DataBoundItem != null)
                {
                    if (selectedRow.DataBoundItem is Account account)
                    {
                        account.Customerid = selectedRow.Cells["Customerid"].Value?.ToString();
                        account.DateOpened = DateOnly.Parse(selectedRow.Cells["DateOpened"].Value?.ToString() ?? DateOnly.MinValue.ToString());
                        account.Balance = double.Parse(selectedRow.Cells["Balance"].Value?.ToString());
                        try
                        {
                            _accountController.Update(account);
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show($"Error updating account: {ex.Message}");
                        }
                    }
                }
            }
        }


        private void Form7_Load(object sender, EventArgs e)
        {
            // Hàm xử lý khi Form7 load
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Account account = (Account)GetDataFromText();
            if (_accountController.Create(account))
            {
                lblStatus.Text = "Account added successfully at " + DateTime.Now.ToString("HH:mm:ss");
            }
            else
            {
                lblStatus.Text = "Failed to add account.";
            }
            LoadAccountData();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(selectedAccountId))
            {
                _accountController.Delete(selectedAccountId);
                LoadAccountData();

                MessageBox.Show("Account deleted successfully!");
                selectedAccountId = null;
            }
            else
            {
                MessageBox.Show("Please select an account to delete.");
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form2 f2 = new Form2(UserSession.CurrentUserRole);
            f2.Show();
            this.Hide();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            Account customer = (Account)GetDataFromText();
            if (_accountController.Update(customer))
            {
                lblStatus.Text = "Account updated successfully at " + DateTime.Now.ToString("HH:mm:ss");
            }// Cập nhật thông tin khách hàng
            else
            {
                lblStatus.Text = "Account updated fail because invalid input at " + DateTime.Now.ToString("HH:mm:ss");
            }
            LoadAccountData(); // Tải lại dữ liệu sau khi cập nhật
        }

        private void button5_Click(object sender, EventArgs e)
        {
            string searchId = txtSearch.Text; // Lấy từ khóa tìm kiếm từ TextBox

            if (!string.IsNullOrEmpty(searchId))
            {
                // Gọi phương thức Load(object id) từ controller để tìm kiếm
                if (_accountController.Load(searchId))
                {
                    // Lấy kết quả tìm kiếm từ Items và hiển thị trong DataGridView
                    var customer = _accountController.Items.Cast<Account>().FirstOrDefault();
                    if (customer != null)
                    {
                        // Hiển thị thông tin khách hàng đã tìm được trong DataGridView
                        dataGridView1.DataSource = new List<Account> { customer };
                    }
                    else
                    {
                        MessageBox.Show("Không tìm thấy khách hàng.");
                    }
                }
                else
                {
                    MessageBox.Show("Không tìm thấy khách hàng.");
                }
            }
            else
            {
                // Nếu không có từ khóa tìm kiếm, tải lại toàn bộ dữ liệu
                LoadAccountData();
            }
        }

        private void txtSearch_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
