﻿namespace _1050080005__TranChau
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            txtBranchId = new TextBox();
            txtBranchName = new TextBox();
            txtBranchHouseNo = new TextBox();
            txtBranchCity = new TextBox();
            dataGridView1 = new DataGridView();
            GroupBox = new GroupBox();
            lblStatus = new Label();
            button1 = new Button();
            button2 = new Button();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            pictureBox1 = new PictureBox();
            button3 = new Button();
            button4 = new Button();
            txtSearch = new TextBox();
            button5 = new Button();
            label6 = new Label();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            GroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // txtBranchId
            // 
            txtBranchId.Location = new Point(282, 152);
            txtBranchId.Name = "txtBranchId";
            txtBranchId.Size = new Size(237, 27);
            txtBranchId.TabIndex = 0;
            // 
            // txtBranchName
            // 
            txtBranchName.Location = new Point(282, 185);
            txtBranchName.Name = "txtBranchName";
            txtBranchName.Size = new Size(237, 27);
            txtBranchName.TabIndex = 1;
            txtBranchName.TextChanged += txtBranchName_TextChanged;
            // 
            // txtBranchHouseNo
            // 
            txtBranchHouseNo.Location = new Point(282, 218);
            txtBranchHouseNo.Name = "txtBranchHouseNo";
            txtBranchHouseNo.Size = new Size(237, 27);
            txtBranchHouseNo.TabIndex = 2;
            // 
            // txtBranchCity
            // 
            txtBranchCity.Location = new Point(282, 251);
            txtBranchCity.Name = "txtBranchCity";
            txtBranchCity.Size = new Size(237, 27);
            txtBranchCity.TabIndex = 3;
            // 
            // dataGridView1
            // 
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(163, 319);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.Size = new Size(490, 155);
            dataGridView1.TabIndex = 4;
            // 
            // GroupBox
            // 
            GroupBox.Controls.Add(lblStatus);
            GroupBox.Location = new Point(163, 480);
            GroupBox.Name = "GroupBox";
            GroupBox.Size = new Size(490, 92);
            GroupBox.TabIndex = 5;
            GroupBox.TabStop = false;
            GroupBox.Text = "Status";
            // 
            // lblStatus
            // 
            lblStatus.AutoSize = true;
            lblStatus.Location = new Point(9, 27);
            lblStatus.Name = "lblStatus";
            lblStatus.Size = new Size(0, 20);
            lblStatus.TabIndex = 0;
            // 
            // button1
            // 
            button1.Location = new Point(282, 284);
            button1.Name = "button1";
            button1.Size = new Size(94, 29);
            button1.TabIndex = 6;
            button1.Text = "Submit";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Location = new Point(382, 284);
            button2.Name = "button2";
            button2.Size = new Size(94, 29);
            button2.TabIndex = 7;
            button2.Text = "Delete";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 19.8000011F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.ForeColor = SystemColors.ControlText;
            label1.Location = new Point(325, 12);
            label1.Name = "label1";
            label1.Size = new Size(151, 46);
            label1.TabIndex = 8;
            label1.Text = "BRANCH";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(205, 152);
            label2.Name = "label2";
            label2.Size = new Size(24, 20);
            label2.TabIndex = 9;
            label2.Text = "ID";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(205, 185);
            label3.Name = "label3";
            label3.Size = new Size(49, 20);
            label3.TabIndex = 10;
            label3.Text = "Name";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(205, 218);
            label4.Name = "label4";
            label4.Size = new Size(71, 20);
            label4.TabIndex = 11;
            label4.Text = "HouseNo";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(205, 258);
            label5.Name = "label5";
            label5.Size = new Size(34, 20);
            label5.TabIndex = 12;
            label5.Text = "City";
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.seoul;
            pictureBox1.Location = new Point(-1, 0);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(805, 592);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 13;
            pictureBox1.TabStop = false;
            // 
            // button3
            // 
            button3.Location = new Point(12, 12);
            button3.Name = "button3";
            button3.Size = new Size(94, 29);
            button3.TabIndex = 14;
            button3.Text = "Back";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // button4
            // 
            button4.Location = new Point(482, 284);
            button4.Name = "button4";
            button4.Size = new Size(94, 29);
            button4.TabIndex = 15;
            button4.Text = "Update";
            button4.UseVisualStyleBackColor = true;
            button4.Click += button4_Click;
            // 
            // txtSearch
            // 
            txtSearch.Location = new Point(178, 61);
            txtSearch.Name = "txtSearch";
            txtSearch.Size = new Size(398, 27);
            txtSearch.TabIndex = 16;
            // 
            // button5
            // 
            button5.Location = new Point(568, 60);
            button5.Name = "button5";
            button5.Size = new Size(94, 29);
            button5.TabIndex = 17;
            button5.Text = "Search";
            button5.UseVisualStyleBackColor = true;
            button5.Click += button5_Click;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(98, 64);
            label6.Name = "label6";
            label6.Size = new Size(74, 20);
            label6.TabIndex = 18;
            label6.Text = "Tìm kiếm ";
            // 
            // Form3
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 584);
            Controls.Add(label6);
            Controls.Add(button5);
            Controls.Add(txtSearch);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(GroupBox);
            Controls.Add(dataGridView1);
            Controls.Add(txtBranchCity);
            Controls.Add(txtBranchHouseNo);
            Controls.Add(txtBranchName);
            Controls.Add(txtBranchId);
            Controls.Add(pictureBox1);
            Name = "Form3";
            Text = "Branch";
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            GroupBox.ResumeLayout(false);
            GroupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox txtBranchId;
        private TextBox txtBranchName;
        private TextBox txtBranchHouseNo;
        private TextBox txtBranchCity;
        private DataGridView dataGridView1;
        private GroupBox GroupBox;
        private Button button1;
        private Button button2;
        private Label lblStatus;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private PictureBox pictureBox1;
        private Button button3;
        private Button button4;
        private TextBox txtSearch;
        private Button button5;
        private Label label6;
    }
}