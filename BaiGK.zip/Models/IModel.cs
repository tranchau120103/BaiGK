﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _1050080005__TranChau.Models
{
    public interface IModel
    {
        bool IsValid();
    }
}
